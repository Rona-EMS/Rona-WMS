import { KioskData } from "@/components/admin/kiosk-data"

export default function KioskDataPage() {
  return <KioskData />
}
