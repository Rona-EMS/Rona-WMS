export const fontSans = {
  variable: `font-var('sans')`,
}
